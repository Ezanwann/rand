onmessage=e=>{
            let w=e.data[0];
            let r=JSON.stringify(w);
            postMessage(r);
        }