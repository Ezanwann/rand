let a=`
널 우연히 마주친 척할래
못 본 척 지나갈래
You're so fine
Gotta gotta get to know ya
나와 나와 걸어가 줘

지금 돌아서면
I need ya, need ya, need ya
To look at me back
Hey 다 들켰었나
널 보면 하트가 튀어나와


아주 눈부시게
Honestly 우리 사이에
He's been totally lyin', yeah

내 생일 파티에 너만 못 온 그날
혜진이가 엄청 혼났던 그날
지원이가 여친이랑 헤어진 그날
걔는 언제나 네가 없이 그날
너무 멋있는 옷을 입고 그날
Heard him say

We can go wherever you like
Baby, say the words and I'm down
All I need is you on my side
We can go whenever you like
Now, where are you? (Mm-mhm)
What's your ETA? What's your ETA? (Mm-mhm-mm)
What's your ETA? What's your ETA? (Mm-mhm)
What's your ETA? What's your ETA?
I'll be there right now, lose that boy on her arm

아파 맘이 네가 걔 못 잊을 때
내 말 믿어 you deserve better than that
내가 도와줄게
걔는 그냥 playin'
Boys be always lyin', yeah

내 생일 파티에 너만 못 온 그날
혜진이가 엄청 혼났던 그날
지원이가 여친이랑 헤어진 그날

I'm super shy, super shy
But wait a minute while I make you mine, make you mine
떨리는 지금도, you're on my mind all the time
I wanna tell you but, I'm super shy, super shy
I'm super shy, super shy
But wait a minute while I make you mine, make you mine
떨리는 지금도, you're on my mind all the time
I wanna tell you but I'm super shy, super shy

나 원래 말도 잘하고 그런데 왜 이런지
I don't like that
Something odd about you
Yeah, you're special and you know it
You're the top, babe

I'm super shy, super shy
But wait a minute while I make you mine, make you mine
떨리는 지금도, you're on my mind all the time
I wanna tell you but, I'm super shy, super shy
I'm super shy, super shy
But wait a minute while I make you mine, make you mine
떨리는 지금도, you're on my mind all the time
I wanna tell you but I'm super shy, super shy

You don't even know my name
Do ya?
You don't even know my name
Do ya-a?
누구보다도
이 노래는 it's about you baby
Only you
You you you
You you you you

내가 힘들 때
울 것 같을 때
기운도 이젠
나지 않을 때
It's you 날 걱정하네
It's you 날 웃게하네
말 안 해도 돼
Boy what do you say

(They keep on asking me, "who is he?")
멀리든 언제든지 달려와
(They keep on asking me, "who is he?")
바쁜 척도 없이 넌 나타나
(They keep on asking me, "who is he?")
이게 말이 되니 난 물어봐
(They keep on asking me, "who is he?")
너는 말야
He's the one that's living in my system baby

Oh my oh my God
예상했어 나
I was really hoping
That he will come through
Oh my oh my God
단 너뿐이야
Asking all the time about what I should do

No I can never let him go
너만 생각나 24
난 행운아야 정말로 I know, I know
널 알기 전까지는 나
의미 없었어 전부 다
내 맘이 끝이 없는 걸 I know, I know
I'm going crazy right?

어디서든
몇 번이든
There ain't nothing else that
I would hold on to
I hear his voice
Through all the noise
잠시라도 내 손 놓지 마 no, no

You don't even know my name
Do ya?
You don't even know my name
Do ya-a?

걔는 언제나 네가 없이 그날
너무 멋있는 옷을 입고 그날
Heard him say
Baby, got me looking so crazy
빠져버리는 daydream
Got me feeling you

보고 싶은 생각에
들어간 우리 창에
나는 말을 거는데
보내지는 않을래
느린 한마디보다
조용함이 더 좋아
기다리고 있지만
매일 이런 건 아냐

난 재미없어 게임 같은 건
다 필요 없어
아무리 좋아도 널 no
말로만은 지겨운걸
먼저 와서 보여줘
먼저 와서 보여줘
'Cause I'm not gonna be the one to get hurt

Hurt (nah, nah)
I'm not gonna be the one to get hurt
Hurt (nah, nah)
I'm not gonna be the one to get hurt
Hurt (oh, oh, ooh)
I'm not gonna be the one to get hurt
(Oh, oh, ooh)
I'm not gonna be the one to get hurt
(Oh, oh, ooh)
I'm not gonna be the one to get hurt
(Oh, oh, ooh)

매일 잠들기 전에
그리고 또 아침에
쥐고 있는 내 손엔
너없는 화면인데
느린 한마디보다
조용함이 더 좋아
기다리고 있지만
매일 이런 건 아냐

난 재미없어 게임 같은 건
다 필요없어
아무리 좋아도 널 no
Stormy night, cloudy sky
In the moment, you and I
One more chance
너와 나 다시 한번 만나게
서로에게 향하게

My feeling's getting deeper
내 심박수를 믿어
우리 인연은 깊어
I gotta see the meaning of it

I don't know what we've done
되돌아가긴 싫어
もう知っている
Don't know what we've been sold
見つけられるよ
So it's sure

Golden moon, diamond stars
In a moment, you and I
Second chance, しょうがない
もう少し待って
너와 내게 향하게

My feeling's getting deeper
내 심박수를 믿어
우리 인연은 깊어
I gotta see the meaning of it

I don't know what we've done
되돌아가긴 싫어
もう知っている
Don't know what we've been sold
見つけられるよ
So it's sure
Always up and down (No more)
생각 또 생각
Spinnin' 'round and 'round
Changing my mind

수상해서 그렇지
이런 헛소리 (No more)
How it's supposed to be
그만해 'Cause it's clear (It's simple)
It's like biting an apple

Toxic lover
You're no better 거기 숨지 말고 얼른 나와
You little demon in my storyline
Don't knock on my door, I'll see you out

And don't you know how sweet it tastes (How sweet it tastes)
Ya don't you know how sweet it tastes (How sweet it tastes)
Ya don't you know how sweet it tastes
Now that I'm without you

나 더는 묻지 않을래 (How sweet it tastes)
알려 주지 않아도 돼 (How sweet it tastes)
Wow, don't you know how sweet it tastes
Now that I'm without you

모든 게 Typical
So I've been praying so hard for a miracle
부르고 있어 나의 이름을
더는 안 봐 Drama, it's good karma
Done scrolling thousand times
다 알고 있어 뻔한 수작일 뿐이야
완전 쉬운 공식이야
It's like biting an apple

And don't you know how sweet it tastes (How sweet it tastes)
Ya don't you know how sweet it tastes (How sweet it tastes)
Ya don't you know how sweet it tastes
Now that I'm without you
You just get my heart pump, pumping
Everytime that you're here around me
노랫 소리가 또 흘러나와, yeah (Yeah)
오늘 오래 걸린 이유
I'm always so excited to meet you
내 향기가 널 먼저 찾아가 (먼저 찾아가), yeah

눈 감아도 기억나게, 어디라도 따라갈래
You're so delicate 거품 속에, 숨었네
Uh-uh-uh
Oh, you make my heart melt away
You're a softie 구름 같아
이건 말로 설명 못해, you got me
Oh, oh-oh, oh
이미 우린 저기 멀리 높이 있는 풍선같이
Have you right here in a basket

Oh, my baby, sweet like bubble gum
Bouncin' like playin' ball
더 높이 올려줘
We're gonna fly away
Sweet like bubble yum
So smooth, soft like a hug
더 멀리 날려줘
Let's go far away

You're my favorite flavor
Bubble gum
Bubble, bubble, bubble, bubble, bubble, bubble
Bubble, bubble, bubble gum

얘기 늘어놓아 줄줄
Like I got nothing better to do
내 손바닥 안에 쏙 들어와, yeah (Yeah)
나만 알고 싶은 비밀 (Oh-oh)
Stay in the middle
Like you a little
Don't want no riddle
말해줘 say it back
Oh say it ditto
아침은 너무 멀어
So say it ditto

훌쩍 커버렸어
함께한 기억처럼
널 보는 내 마음은
어느새 여름 지나 가을
기다렸지 all this time
Do you want somebody
Like I want somebody
날 보고 웃었지만
Do you think about me now yeah
All the time yeah
All the time

I got no time to lose
내 길었던 하루
난 보고 싶어
Ra-ta-ta-ta 울린 심장 (Ra-ta-ta-ta)
I got nothing to lose
널 좋아한다고 wooah wooah wooah
Ra-ta-ta-ta 울린 심장 (Ra-ta-ta-ta)
But I don't want to

Stay in the middle
Like you a little
Don't want no riddle
말해줘 say it back
Oh say it ditto
아침은 너무 멀어
So say it ditto
I don't want to
Walk in this 미로
다 아는 건 아니어도
바라던 대로
말해줘 Say it back
Oh say it ditto
I want you so, want you
So say it ditto
All I know is I need this feeling (Oh-oh)
내 윤기가 널 먼저 사로잡아, yeah (Ooh, oh)


It's supernatural
It's supernatural

말로만은 지겨운걸
먼저 와서 보여줘
먼저 와서 보여줘
'Cause I'm not gonna be the one to get hurt

Hurt (nah, nah)
I'm not gonna be the one to get hurt
Hurt (nah, nah)


Look it's a new me
Switched it up, who's this?
우릴 봐 NewJeans
So fresh, so clean

얼마나
기다렸던 날
드디어
Time to step out
또 한 번 더
Ready for sure
To have some more

New hair
New tee
NewJeans
Do you see
New hair
New tee
NewJeans
Do you see

New hair
New tee
NewJeans
Do you see
New hair
New tee
NewJeans
Do you see

Make it feel
Like a game
Look at us, we go
On & on again
We'll go on to the end
What we wanna do
On & on again

Make it feel
Like a game
Look at us, we go
On & on again
We'll go on to the end
What we wanna do
On & on again

Look it's a new me
Switched it up, who's this?
들어봐 NewJeans
So fresh, so clean
I'm not gonna be the one to get hurt
Hurt (oh, oh, ooh)
Hurt (oh, oh, ooh)

여기까지야
네가 와있는 곳은
너무 멀었어
I'm not gonna be the one to get hurt

여기까지야
네가 와있는 곳은
너무 멀었어
너도 말해줄래

누가 내게 뭐라든
남들과는 달라 넌
Maybe you could be the one
날 믿어봐 한 번
I'm not looking for just fun
Maybe I could be the one

Oh baby
예민하대 나 lately
너 없이는 매일 매일이 yeah
재미없어 어쩌지

I just want you
Call my phone right now
I just wanna hear you're mine

'Cause I know what you like boy
You're my chemical hype boy
내 지난 날들은
눈 뜨면 잊는 꿈
Hype boy 너만 원해
Hype boy 내가 전해

And we can go high
말해봐 yeah 느껴봐 mm mm
Take him to the sky
You know I hype you boy
눈을 감아
말해봐 yeah 느껴봐 mm mm
Take him to the sky
You know I hype you boy

잠에 들려고 잠에 들려 해도
네 생각에 또 새벽 세 시 uh-oh
알려줄 거야
They can't have you no more
봐봐 여기
내 이름 써있다고 (Yeah)

누가 내게 뭐라든
남들과는 달라 넌
Maybe you could be the one
날 믿어봐 한 번
I'm not looking for just fun
Maybe I could be the one

Oh baby
예민하대 나 lately
너 없이는 매일 매일이 yeah
재미없어 어쩌지

I just want you
Call my phone right now
I just wanna hear you're mine
난 사탕을 찾는 baby (baby)
내 맘은 설레이지
Eyyy, drop the question
Drop the, drop the question
Want attention
Wanna want attention

You give me butterflies you know
내 맘은 온통 paradise
꿈에서 깨워주지 마

You got me looking for attention
You got me looking for attention





내가 만든 쿠키
너를 위해 구웠지
But you know that it ain't for free, yeah

내가 만든 쿠키
너무 부드러우니
자꾸만 떠오르니

널 choco-chip으로
Sprinkle로
입맛 버리게 만들고 싶어
숨기고 있지만 널 더 보고 싶어

If you want it
You can get it
If you want it
네 목소리를 또 들려줘 boy

식사는 없어 배고파도
음료는 없어 목말라도
달콤한 맛만 디저트만 만
원하게 될 거 알잖아

식사는 없어 배고파도
음료는 없어 목말라도
달콤한 맛만 디저트만 만
원하게 될 거 알잖아

내가 만든 쿠키
너에게는 독이지
네 마음속을 녹이지
So good, yeah

Looking at my cookie
역시 향기부터 다르니 (Taste it)
한입은 모자라니

널 choco-chip으로
Sprinkle로
정신 못 차리게 만들고 싶어
숨기고 있지만 널 더 보고 싶어

If you want it
You can get it
If you want it
네 목소리를 또 들려줘 boy

식사는 없어 배고파도
음료는 없어 목말라도
달콤한 맛만 디저트만 만
원하게 될 거 알잖아
가끔은 정말
헷갈리지만
분명한 건
Got me looking for attention
You got me looking for attention
(You got me looking for attention yeah)
You got me looking for attention


`;