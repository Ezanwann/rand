let gdataL=[
"a_a.js"
];

let gpixelL=[
"c2.js"
]
let dtextL=[
"bd.js"
];

let auUrls=[

];


let W=60;
let H=30;


function loadSc(ob,f=()=>{}){
   for(let i of ob){
     let sc=document.createElement("script");
     sc.src="./r/"+i;
     let scs=document.querySelectorAll("script");
     document.body.insertBefore(sc,scs[0]);
      sc.onload=f;
    }

}